
  # 규정 관리 웹사이트

  This is a code bundle for 규정 관리 웹사이트. The original project is available at https://www.figma.com/design/SanyqCdAxQR9A178wpFwgt/%EA%B7%9C%EC%A0%95-%EA%B4%80%EB%A6%AC-%EC%9B%B9%EC%82%AC%EC%9D%B4%ED%8A%B8.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  