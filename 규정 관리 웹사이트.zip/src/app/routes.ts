import { createBrowserRouter } from 'react-router';
import { Home } from './pages/Home';
import { LawCorporatePage } from './pages/LawCorporatePage';
import { RegulationsPage } from './pages/RegulationsPage';
import { CommitteePage } from './pages/CommitteePage';
import { AcademicPage } from './pages/AcademicPage';
import { AffiliatedPage } from './pages/AffiliatedPage';
import { OthersPage } from './pages/OthersPage';
import { SearchResults } from './pages/SearchResults';
import { RegulationDetail } from './pages/RegulationDetail';
import { AdminPage } from './pages/AdminPage';
import { ErrorPage } from './pages/ErrorPage';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Home,
    ErrorBoundary: ErrorPage,
  },
  {
    path: '/search',
    Component: SearchResults,
    ErrorBoundary: ErrorPage,
  },
  {
    path: '/regulation/:id',
    Component: RegulationDetail,
    ErrorBoundary: ErrorPage,
  },
  {
    path: '/law-corporate',
    Component: LawCorporatePage,
    ErrorBoundary: ErrorPage,
  },
  {
    path: '/regulations',
    Component: RegulationsPage,
    ErrorBoundary: ErrorPage,
  },
  {
    path: '/committee',
    Component: CommitteePage,
    ErrorBoundary: ErrorPage,
  },
  {
    path: '/academic',
    Component: AcademicPage,
    ErrorBoundary: ErrorPage,
  },
  {
    path: '/affiliated',
    Component: AffiliatedPage,
    ErrorBoundary: ErrorPage,
  },
  {
    path: '/others',
    Component: OthersPage,
    ErrorBoundary: ErrorPage,
  },
  {
    path: '/admin',
    Component: AdminPage,
    ErrorBoundary: ErrorPage,
  },
  {
    path: '*',
    Component: ErrorPage,
  },
]);