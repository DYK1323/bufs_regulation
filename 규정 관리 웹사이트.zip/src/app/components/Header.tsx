import { Link, useLocation } from 'react-router';

const categories = [
  { name: '법인', path: '/law-corporate' },
  { name: '학칙', path: '/regulations' },
  { name: '위원회', path: '/committee' },
  { name: '학사규정', path: '/academic' },
  { name: '부속기관', path: '/affiliated' },
  { name: '기타', path: '/others' },
];

export function Header() {
  const location = useLocation();

  return (
    <header className="border-b sticky top-0 z-50 bg-white">
      <div className="px-8 py-4 bg-[#0d4a7a]">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <Link to="/" className="text-xl font-bold text-white hover:opacity-90 transition-opacity">
            부산외국어대학교 규정관리시스템
          </Link>
          
          <nav className="flex gap-8">
            {categories.map((category) => (
              <Link
                key={category.path}
                to={category.path}
                className={`transition-colors font-medium ${
                  location.pathname === category.path
                    ? 'text-primary'
                    : 'text-white/90 hover:text-white'
                }`}
              >
                {category.name}
              </Link>
            ))}
          </nav>
        </div>
      </div>
    </header>
  );
}