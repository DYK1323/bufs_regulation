import { useState } from 'react';
import { Settings } from 'lucide-react';
import { Button } from './ui/button';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription, 
  DialogFooter 
} from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { toast } from 'sonner';
import { useNavigate } from 'react-router';

export function AdminButton() {
  const [isOpen, setIsOpen] = useState(false);
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleClearCache = () => {
    if (password === 'admin123') {
      // 캐시 초기화 로직
      localStorage.clear();
      sessionStorage.clear();
      toast.success('캐시가 성공적으로 초기화되었습니다.');
      setPassword('');
      setIsOpen(false);
    } else {
      toast.error('암호가 올바르지 않습니다.');
    }
  };

  const handleAdminPage = () => {
    if (password === 'admin123') {
      setIsOpen(false);
      setPassword('');
      navigate('/admin');
    } else {
      toast.error('암호가 올바르지 않습니다.');
    }
  };

  return (
    <>
      <Button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 rounded-full w-14 h-14 shadow-lg hover:shadow-xl transition-shadow bg-primary hover:bg-[#E59A00] text-primary-foreground bg-[#0d4a7a]"
        size="icon"
      >
        <Settings className="w-6 h-6 text-white" />
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>관리자 설정</DialogTitle>
            <DialogDescription>
              캐시를 초기화하려면 관리자 암호를 입력하세요.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <Label htmlFor="password">암호</Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="관리자 암호 입력"
              className="mt-2"
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleClearCache();
                }
              }}
            />
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsOpen(false)}>
              닫기
            </Button>
            <Button onClick={handleClearCache}>
              캐시 초기화
            </Button>
            <Button onClick={handleAdminPage}>
              관리자 페이지로 이동
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}