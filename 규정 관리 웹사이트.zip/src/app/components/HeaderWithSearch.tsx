import { Link, useLocation, useNavigate } from 'react-router';
import { Search } from 'lucide-react';
import { Input } from './ui/input';
import { useState } from 'react';
import logo from 'figma:asset/de1bddd18bb293cf97c6c05da59f918b801ce154.png';

const categories = [
  { name: '법인', path: '/law-corporate' },
  { name: '학칙', path: '/regulations' },
  { name: '위원회', path: '/committee' },
  { name: '학사규정', path: '/academic' },
  { name: '부속기관', path: '/affiliated' },
  { name: '기타', path: '/others' },
];

export function HeaderWithSearch() {
  const location = useLocation();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
      setSearchQuery('');
    }
  };

  return (
    <header className="border-b border-[#0d4a7a] sticky top-0 z-50 bg-white">
      <div className="px-8 py-4">
        <div className="flex items-center justify-between gap-6 max-w-7xl mx-auto">
          <Link to="/" className="text-xl font-bold whitespace-nowrap text-black hover:opacity-90 transition-opacity flex items-center text-[#404040]">
            <img src={logo} alt="부산외국어대학교 로고" className="h-[1.5em] mr-4" />
            부산외국어대학교 규정관리시스템
          </Link>
          
          <nav className="flex gap-6">
            {categories.map((category) => (
              <Link
                key={category.path}
                to={category.path}
                className={`transition-colors whitespace-nowrap font-medium ${
                  location.pathname === category.path
                    ? 'text-primary'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                {category.name}
              </Link>
            ))}
          </nav>

          <form onSubmit={handleSearch} className="relative w-72">
            <Search className="absolute left-0 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              type="text"
              placeholder="규정 검색..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-8 pr-4 py-2 w-full border-0 border-b border-gray-300 rounded-none focus:border-gray-400 focus:ring-0 focus-visible:ring-0 focus-visible:ring-offset-0 bg-transparent text-gray-700 placeholder:text-gray-500"
            />
          </form>
        </div>
      </div>
    </header>
  );
}