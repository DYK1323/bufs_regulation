import { CategoryPage } from './CategoryPage';

const mockRegulations = [
  { id: 18, title: '부산외국어대학교 중앙도서관 운영규정', date: '2024.01.15', category: '부속기관', status: 'active' as const },
  { id: 19, title: '부산외국어대학교 박물관 운영규정', date: '2023.11.20', category: '부속기관', status: 'active' as const },
  { id: 20, title: '부산외국어대학교 평생교육원 운영규정', date: '2024.02.10', category: '부속기관', status: 'active' as const },
  { id: 21, title: '부산외국어대학교 언어교육원 운영규정', date: '2024.03.01', category: '부속기관', status: 'active' as const },
];

export function AffiliatedPage() {
  return <CategoryPage category="부속기관" regulations={mockRegulations} />;
}
