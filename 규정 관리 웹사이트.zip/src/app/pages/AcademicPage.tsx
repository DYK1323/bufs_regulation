import { CategoryPage } from './CategoryPage';
import { HeaderWithSearch } from '../components/HeaderWithSearch';
import { FileText, Calendar, Download } from 'lucide-react';
import { useNavigate } from 'react-router';
import { Button } from '../components/ui/button';
import { AdminButton } from '../components/AdminButton';
import { useState } from 'react';

const mockRegulations = [
  { id: 13, title: '부산외국어대학교 학사운영규정', date: '2024.03.01', category: '학사규정', subCategory: '일반행정', status: 'active' as const },
  { id: 14, title: '부산외국어대학교 수업 및 학점인정 규정', date: '2024.02.25', category: '학사규정', subCategory: '교무행정', status: 'active' as const },
  { id: 15, title: '부산외국어대학교 학생 성적관리 규정', date: '2024.01.30', category: '학사규정', subCategory: '학사행정', status: 'active' as const },
  { id: 16, title: '부산외국어대학교 졸업인증제 운영규정', date: '2023.12.15', category: '학사규정', subCategory: '학사행정', status: 'revised' as const },
  { id: 17, title: '부산외국어대학교 복수전공 및 부전공 규정', date: '2024.02.01', category: '학사규정', subCategory: '학생행정', status: 'active' as const },
  { id: 18, title: '부산외국어대학교 학생회 운영규정', date: '2024.01.15', category: '학사규정', subCategory: '학생행정', status: 'active' as const },
  { id: 19, title: '부산외국어대학교 강의평가 운영규정', date: '2023.12.01', category: '학사규정', subCategory: '교무행정', status: 'active' as const },
  { id: 20, title: '부산외국어대학교 교육과정 편성 및 운영규정', date: '2023.11.20', category: '학사규정', subCategory: '일반행정', status: 'active' as const },
];

const subCategories = ['전체', '일반행정', '교무행정', '학사행정', '학생행정'];

export function AcademicPage() {
  const [selectedSubCategory, setSelectedSubCategory] = useState('전체');
  const navigate = useNavigate();

  const filteredRegulations = selectedSubCategory === '전체' 
    ? mockRegulations 
    : mockRegulations.filter(reg => reg.subCategory === selectedSubCategory);

  const getStatusBadge = (status: string) => {
    const styles = {
      active: 'bg-green-100 text-green-800',
      revised: 'bg-blue-100 text-blue-800',
      archived: 'bg-gray-100 text-gray-800',
    };
    const labels = {
      active: '시행',
      revised: '개정',
      archived: '폐지',
    };
    return (
      <span className={`px-2 py-1 rounded-full text-xs ${styles[status as keyof typeof styles]}`}>
        {labels[status as keyof typeof labels]}
      </span>
    );
  };

  const handleRegulationClick = (id: number) => {
    navigate(`/regulation/${id}`);
  };

  return (
    <div className="min-h-screen bg-background">
      <HeaderWithSearch />
      
      <main className="max-w-7xl mx-auto px-8 py-12">
        <div className="mb-6 pb-4 border-b-2 border-border">
          <h1 className="text-3xl mb-2 text-center px-[0px] pt-[10px] pb-[0px]">학사규정</h1>
          <p className="text-muted-foreground text-center px-[0px] py-[10px]">총 {filteredRegulations.length}개의 규정이 있습니다</p>
        </div>

        <div className="mb-6">
          <div className="flex gap-2 border-b border-border">
            {subCategories.map((subCat) => (
              <button
                key={subCat}
                onClick={() => setSelectedSubCategory(subCat)}
                className={`px-6 py-3 font-medium transition-colors border-b-2 -mb-px ${
                  selectedSubCategory === subCat
                    ? 'border-primary text-primary'
                    : 'border-transparent text-muted-foreground hover:text-foreground'
                }`}
              >
                {subCat}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="px-6 py-4 text-left font-bold text-sm">규정명</th>
                <th className="px-6 py-4 text-left font-bold text-sm w-48">최근개정일</th>
                <th className="px-6 py-4 text-left font-bold text-sm w-32">상태</th>
              </tr>
            </thead>
            <tbody>
              {filteredRegulations.map((regulation, index) => (
                <tr 
                  key={regulation.id} 
                  className="border-b border-border hover:bg-muted/40 transition-colors cursor-pointer"
                  onClick={() => handleRegulationClick(regulation.id)}
                >
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <FileText className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                      <span className="text-sm text-foreground hover:text-primary">
                        {regulation.title}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Calendar className="w-4 h-4" />
                      {regulation.date}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    {getStatusBadge(regulation.status)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>

      <AdminButton />
    </div>
  );
}