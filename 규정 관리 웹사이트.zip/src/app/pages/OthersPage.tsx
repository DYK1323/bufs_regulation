import { CategoryPage } from './CategoryPage';

const mockRegulations = [
  { id: 22, title: '부산외국어대학교 정보보안 관리규정', date: '2024.02.20', category: '기타', status: 'active' as const },
  { id: 23, title: '부산외국어대학교 시설관리 규정', date: '2024.01.25', category: '기타', status: 'active' as const },
  { id: 24, title: '부산외국어대학교 문서관리 규정', date: '2023.12.30', category: '기타', status: 'revised' as const },
  { id: 25, title: '부산외국어대학교 연구윤리 규정', date: '2024.03.10', category: '기타', status: 'active' as const },
];

export function OthersPage() {
  return <CategoryPage category="기타" regulations={mockRegulations} />;
}
