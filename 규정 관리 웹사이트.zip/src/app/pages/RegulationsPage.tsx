import { CategoryPage } from './CategoryPage';

const mockRegulations = [
  { id: 5, title: '부산외국어대학교 학칙', date: '2024.03.01', category: '학칙', status: 'active' as const },
  { id: 6, title: '부산외국어대학교 학칙 시행세칙', date: '2024.03.01', category: '학칙', status: 'active' as const },
  { id: 7, title: '부산외국어대학교 대학원 학칙', date: '2024.01.20', category: '학칙', status: 'active' as const },
  { id: 8, title: '부산외국어대학교 특수대학원 학칙', date: '2023.11.15', category: '학칙', status: 'revised' as const },
];

export function RegulationsPage() {
  return <CategoryPage category="학칙" regulations={mockRegulations} />;
}
