import { Link } from 'react-router';
import { Button } from '../components/ui/button';

export function ErrorPage() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
      <div className="text-center">
        <h1 className="text-6xl font-bold text-[#0d4a7a] mb-4">404</h1>
        <h2 className="text-2xl font-semibold text-gray-800 mb-4">
          페이지를 찾을 수 없습니다
        </h2>
        <p className="text-gray-600 mb-8">
          요청하신 페이지가 존재하지 않거나 이동되었습니다.
        </p>
        <Link to="/">
          <Button className="bg-[#FDB71A] hover:bg-[#E59A00] text-white">
            메인으로 돌아가기
          </Button>
        </Link>
      </div>
    </div>
  );
}
