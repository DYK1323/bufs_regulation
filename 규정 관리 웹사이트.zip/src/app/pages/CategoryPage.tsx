import { HeaderWithSearch } from '../components/HeaderWithSearch';
import { FileText, Calendar, Download } from 'lucide-react';
import { useNavigate } from 'react-router';
import { Button } from '../components/ui/button';
import { AdminButton } from '../components/AdminButton';

interface Regulation {
  id: number;
  title: string;
  date: string;
  category: string;
  status: 'active' | 'revised' | 'archived';
}

interface CategoryPageProps {
  category: string;
  regulations: Regulation[];
}

export function CategoryPage({ category, regulations }: CategoryPageProps) {
  const navigate = useNavigate();
  
  const getStatusBadge = (status: string) => {
    const styles = {
      active: 'bg-green-100 text-green-800',
      revised: 'bg-blue-100 text-blue-800',
      archived: 'bg-gray-100 text-gray-800',
    };
    const labels = {
      active: '시행',
      revised: '개정',
      archived: '폐지',
    };
    return (
      <span className={`px-2 py-1 rounded-full text-xs ${styles[status as keyof typeof styles]}`}>
        {labels[status as keyof typeof labels]}
      </span>
    );
  };

  const handleRegulationClick = (id: number) => {
    navigate(`/regulation/${id}`);
  };

  return (
    <div className="min-h-screen bg-background">
      <HeaderWithSearch />
      
      <main className="max-w-7xl mx-auto px-8 py-12">
        <div className="mb-6 pb-4 border-b-2 border-border">
          <h1 className="text-3xl mb-2 text-center px-[0px] pt-[10px] pb-[0px]">{category}</h1>
          <p className="text-muted-foreground text-center px-[0px] py-[10px]">총 {regulations.length}개의 규정이 있습니다</p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="px-6 py-4 text-left font-bold text-sm">규정명</th>
                <th className="px-6 py-4 text-left font-bold text-sm w-48">최근개정일</th>
                <th className="px-6 py-4 text-left font-bold text-sm w-32">상태</th>
              </tr>
            </thead>
            <tbody>
              {regulations.map((regulation, index) => (
                <tr 
                  key={regulation.id} 
                  className="border-b border-border hover:bg-muted/40 transition-colors cursor-pointer"
                  onClick={() => handleRegulationClick(regulation.id)}
                >
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <FileText className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                      <span className="text-sm text-foreground hover:text-primary">
                        {regulation.title}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Calendar className="w-4 h-4" />
                      {regulation.date}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    {getStatusBadge(regulation.status)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>

      <AdminButton />
    </div>
  );
}