import { useState } from 'react';
import { Search, ChevronDown, ChevronUp, Calendar, FileText } from 'lucide-react';
import { useNavigate } from 'react-router';
import { HeaderWithSearch } from '../components/HeaderWithSearch';
import { Input } from '../components/ui/input';
import { Button } from '../components/ui/button';
import { AdminButton } from '../components/AdminButton';

const recentUpdates = [
  { id: 1, title: '부산외국어대학교 학칙', date: '2024.03.01', category: '학칙', revisions: 5 },
  { id: 2, title: '부산외국어대학교 학사운영규정', date: '2024.03.01', category: '학사규정', revisions: 8 },
  { id: 3, title: '부산외국어대학교 예산위원회 규정', date: '2024.03.05', category: '위원회', revisions: 3 },
  { id: 4, title: '부산외국어대학교 연구윤리 규정', date: '2024.03.10', category: '기타', revisions: 4 },
  { id: 5, title: '부산외국어대학교 수업 및 학점인정 규정', date: '2024.02.25', category: '학사규정', revisions: 6 },
  { id: 6, title: '부산외국어대학교 정보보안 관리규정', date: '2024.02.20', category: '기타', revisions: 7 },
  { id: 7, title: '부산외국어대학교 대학평의원회 규정', date: '2024.02.15', category: '위원회', revisions: 2 },
  { id: 8, title: '부산외국어대학교 회계규정', date: '2024.02.10', category: '법인', revisions: 9 },
  { id: 9, title: '부산외국어대학교 평생교육원 운영규정', date: '2024.02.10', category: '부속기관', revisions: 5 },
  { id: 10, title: '부산외국어대학교 복수전공 및 부전공 규정', date: '2024.02.01', category: '학사규정', revisions: 3 },
  { id: 11, title: '부산외국어대학교 학과운영규정', date: '2024.01.15', category: '학사규정', revisions: 4 },
  { id: 12, title: '부산외국어대학교 학과운영규정', date: '2024.01.15', category: '학사규정', revisions: 4 },
  { id: 13, title: '부산외국어대학교 학과운영규정', date: '2024.01.15', category: '학사규정', revisions: 4 },
  { id: 14, title: '부산외국어대학교 학과운영규정', date: '2024.01.15', category: '학사규정', revisions: 4 },
  { id: 15, title: '부산외국어대학교 학과운영규정', date: '2024.01.15', category: '학사규정', revisions: 4 },
];

const revisionHistory = [
  { version: 5, date: '2024.03.01', description: '제5차 개정' },
  { version: 4, date: '2023.12.15', description: '제4차 개정' },
  { version: 3, date: '2023.09.01', description: '제3차 개정' },
  { version: 2, date: '2023.03.01', description: '제2차 개정' },
  { version: 1, date: '2022.09.01', description: '제정' },
];

export function Home() {
  const [searchQuery, setSearchQuery] = useState('');
  const [showAllUpdates, setShowAllUpdates] = useState(false);
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  const handleRegulationClick = (id: number) => {
    navigate(`/regulation/${id}`);
  };

  const displayedUpdates = showAllUpdates ? recentUpdates : recentUpdates.slice(0, 10);

  return (
    <div className="min-h-screen bg-background">
      <HeaderWithSearch />
      
      <main className="max-w-7xl mx-auto px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl mb-4 text-[#0d4a7a] mt-[60px]">규정 검색하기</h1>
          <p className="text-muted-foreground text-lg">
            부산외국어대학교의 모든 규정을 검색하고 조회할 수 있습니다
          </p>
        </div>
        
        <form onSubmit={handleSearch} className="relative mb-16">
          <div className="relative max-w-2xl mx-auto">
            <div className="relative border border-gray-300 rounded-full overflow-hidden bg-white">
              <Search className="absolute left-5 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
              <Input
                type="text"
                placeholder="규정명, 키워드로 검색하세요..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-14 pr-20 py-3 text-base w-full border-0 focus:ring-0 focus:outline-none bg-transparent"
              />
              <button 
                type="submit"
                className="absolute right-5 top-1/2 transform -translate-y-1/2 px-3 py-1 font-bold text-base text-foreground hover:text-primary transition-colors"
              >
                검색
              </button>
            </div>
          </div>
        </form>

        <div>
          <div className="flex items-center justify-between mb-6 pb-3 border-b-2 border-border">
            <h2 className="text-2xl">최근 개정된 규정</h2>
            <span className="text-sm text-muted-foreground">총 {recentUpdates.length}</span>
          </div>

          <div className="space-y-0">
            {displayedUpdates.map((regulation, index) => (
              <div
                key={`regulation-${regulation.id}`}
                className={`flex items-center justify-between px-6 py-4 hover:bg-muted/40 transition-colors cursor-pointer border-t border-b border-border ${
                  index === 0 ? '' : '-mt-px'
                }`}
                onClick={() => handleRegulationClick(regulation.id)}
              >
                <div className="flex items-center gap-3 flex-1">
                  <FileText className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  <span className="text-sm text-foreground hover:text-primary">
                    {regulation.title}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground ml-6">
                  <Calendar className="w-4 h-4" />
                  {regulation.date}
                </div>
              </div>
            ))}
            {!showAllUpdates && recentUpdates.length > 10 && (
              <div className="p-4 text-center bg-muted/20 -mt-px border-b border-border">
                <button
                  onClick={() => setShowAllUpdates(true)}
                  className="text-sm text-[#0d4a7a] hover:text-[#0d4a7a]/80 font-medium transition-colors"
                >
                  더보기 ({recentUpdates.length - 10}개 더 있음)
                </button>
              </div>
            )}
          </div>
        </div>
      </main>

      <AdminButton />
    </div>
  );
}