import { useSearchParams, useNavigate } from 'react-router';
import { FileText, Calendar, Search as SearchIcon } from 'lucide-react';
import { HeaderWithSearch } from '../components/HeaderWithSearch';
import { AdminButton } from '../components/AdminButton';

// 모의 검색 결과 데이터
const mockRegulationResults = [
  { id: 1, title: '부산외국어대학교 학칙', date: '2024.03.01', category: '학칙' },
  { id: 5, title: '부산외국어대학교 학사운영규정', date: '2024.03.01', category: '학사규정' },
  { id: 13, title: '부산외국어대학교 학생 성적관리 규정', date: '2024.01.30', category: '학사규정' },
];

const mockArticleResults = [
  { 
    id: 1, 
    regulationTitle: '부산외국어대학교 학칙', 
    articleNumber: '제3조', 
    articleTitle: '학생의 권리와 의무',
    date: '2024.03.01',
    content: '학생은 학칙이 정하는 바에 따라 수학할 권리를 가지며, 학칙 및 제 규정을 준수할 의무를 진다. 학생은 교육과정에 참여하고...'
  },
  { 
    id: 2, 
    regulationTitle: '부산외국어대학교 학사운영규정', 
    articleNumber: '제7조', 
    articleTitle: '학기 및 수업일수',
    date: '2024.03.01',
    content: '학년은 매년 3월 1일부터 다음 해 2월 말일까지로 하며, 학기는 2학기로 나눈다. 제1학기는 3월 1일부터 8월 31일까지...'
  },
  { 
    id: 3, 
    regulationTitle: '부산외국어대학교 학생 성적관리 규정', 
    articleNumber: '제12조', 
    articleTitle: '학점 인정',
    date: '2024.01.30',
    content: '학생의 학업성적은 매 학기말 또는 수업종료 후 15일 이내에 평가하여 학점을 부여한다. 학점의 평가는 A+, A, B+, B...'
  },
  { 
    id: 4, 
    regulationTitle: '부산외국어대학교 학칙', 
    articleNumber: '제25조', 
    articleTitle: '학사경고',
    date: '2024.03.01',
    content: '매 학기 평점평균이 1.75 미만인 학생에게는 학사경고를 하고, 연속하여 3회 학사경고를 받은 학생은 제적할 수 있다...'
  },
];

export function SearchResults() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const query = searchParams.get('q') || '';

  const handleRegulationClick = (id: number) => {
    navigate(`/regulation/${id}`);
  };

  const handleArticleClick = (regulationId: number, articleNumber: string) => {
    navigate(`/regulation/${regulationId}?article=${encodeURIComponent(articleNumber)}`);
  };

  return (
    <div className="min-h-screen bg-background">
      <HeaderWithSearch />
      
      <main className="max-w-7xl mx-auto px-8 py-12">
        <div className="mb-8 pb-4 border-b-2 border-border">
          <div className="flex items-center gap-2 text-muted-foreground mb-2">
            <SearchIcon className="w-5 h-5" />
            <span>검색어: <strong className="text-foreground">{query}</strong></span>
          </div>
          <p className="text-sm text-muted-foreground">
            규정명 {mockRegulationResults.length}건, 조문 내용 {mockArticleResults.length}건이 검색되었습니다.
          </p>
        </div>

        {/* 규정명 검색 결과 - 카드 형태 유지 */}
        <section className="mb-12">
          <h2 className="text-2xl mb-6">규정명 검색 결과</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {mockRegulationResults.map((regulation) => (
              <div
                key={regulation.id}
                onClick={() => handleRegulationClick(regulation.id)}
                className="bg-card border border-border rounded-lg p-5 cursor-pointer hover:border-primary hover:bg-accent/30 transition-all"
              >
                <div className="flex items-start gap-3 mb-3">
                  <FileText className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                  <h3 className="font-bold flex-1">{regulation.title}</h3>
                </div>
                <div className="flex items-center gap-3 text-sm text-muted-foreground">
                  <span className="px-2 py-0.5 bg-[#0d4a7a]/10 text-[#0d4a7a] rounded text-xs font-medium">
                    {regulation.category}
                  </span>
                  <div className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>{regulation.date}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* 조문 내용 검색 결과 - 심플한 테이블 */}
        <section>
          <h2 className="text-2xl mb-6">조문 내용 검색 결과</h2>
          <div className="border border-border rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="border-b bg-muted/40">
                  <tr>
                    <th className="px-6 py-4 text-left font-bold w-1/4">규정명</th>
                    <th className="px-6 py-4 text-left font-bold w-32">최근개정일</th>
                    <th className="px-6 py-4 text-left font-bold">내용</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {mockArticleResults.map((article) => (
                    <tr 
                      key={article.id} 
                      className="hover:bg-muted/40 cursor-pointer transition-colors"
                      onClick={() => handleArticleClick(article.id, article.articleNumber)}
                    >
                      <td className="px-6 py-4">
                        <div className="font-bold text-sm mb-1">{article.regulationTitle}</div>
                        <div className="text-xs text-muted-foreground">
                          {article.articleNumber} {article.articleTitle}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-muted-foreground whitespace-nowrap">
                        {article.date}
                      </td>
                      <td className="px-6 py-4">
                        <p className="text-sm text-foreground line-clamp-2">
                          {article.content}
                        </p>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      </main>

      <AdminButton />
    </div>
  );
}