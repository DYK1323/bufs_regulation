import { useState } from 'react';
import { useNavigate } from 'react-router';
import { LayoutDashboard, FileText, List, Edit, AlertTriangle, CheckCircle, LogOut, Plus, Pencil, Trash2, ChevronDown, ChevronUp, Check, ChevronsUpDown } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from '../components/ui/dialog';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '../components/ui/popover';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '../components/ui/command';
import { cn } from '../components/ui/utils';
import { toast } from 'sonner';

type MenuType = 'dashboard' | 'regulations' | 'revision-version' | 'revision-article' | 'validation' | 'approval';

type RegulationStatus = '시행예정' | '시행' | '폐지';

type ApprovalType = '이사회 승인' | '총장 승인';

type RevisionStatus = '작성중' | '개정완료';

interface Regulation {
  code: string;
  part: string;
  chapter: string;
  name: string;
  department: string;
  status: RegulationStatus;
  enactmentDate: string;
  revisionDate: string;
  enforcementDate: string;
  abolitionDate: string;
}

interface RevisionRegulation {
  code: string;
  name: string;
  approvalType: ApprovalType;
}

interface RevisionVersion {
  id: string;
  name: string;
  status: RevisionStatus;
  presidentApprovalDate: string;
  chairmanApprovalDate: string;
  regulations: RevisionRegulation[];
}

export function AdminPage() {
  const [activeMenu, setActiveMenu] = useState<MenuType>('dashboard');
  const [regulations, setRegulations] = useState<Regulation[]>([
    {
      code: 'REG001',
      part: '제1편',
      chapter: '제1장',
      name: '학칙',
      department: '교무처',
      status: '시행',
      enactmentDate: '2020-03-01',
      revisionDate: '2024-01-15',
      enforcementDate: '2024-03-01',
      abolitionDate: '',
    },
    {
      code: 'REG002',
      part: '제1편',
      chapter: '제2장',
      name: '학사운영규정',
      department: '교무처',
      status: '시행',
      enactmentDate: '2020-03-01',
      revisionDate: '2023-12-20',
      enforcementDate: '2024-01-01',
      abolitionDate: '',
    },
  ]);
  const [revisionVersions, setRevisionVersions] = useState<RevisionVersion[]>([
    {
      id: 'V001',
      name: '2024년 1차 ',
      status: '작성중',
      presidentApprovalDate: '2024-01-10',
      chairmanApprovalDate: '2024-01-15',
      regulations: [
        { code: 'REG001', name: '학칙', approvalType: '이사회 승인' },
        { code: 'REG002', name: '학사운영규정', approvalType: '총장 승인' },
      ],
    },
  ]);
  const [expandedVersions, setExpandedVersions] = useState<Set<string>>(new Set());
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isVersionDialogOpen, setIsVersionDialogOpen] = useState(false);
  const [isRevisionRegDialogOpen, setIsRevisionRegDialogOpen] = useState(false);
  const [editingRegulation, setEditingRegulation] = useState<Regulation | null>(null);
  const [currentVersionId, setCurrentVersionId] = useState<string>('');
  const [formData, setFormData] = useState<Regulation>({
    code: '',
    part: '',
    chapter: '',
    name: '',
    department: '',
    status: '시행',
    enactmentDate: '',
    revisionDate: '',
    enforcementDate: '',
    abolitionDate: '',
  });
  const [versionFormData, setVersionFormData] = useState<RevisionVersion>({
    id: '',
    name: '',
    status: '작성중',
    presidentApprovalDate: '',
    chairmanApprovalDate: '',
    regulations: [],
  });
  const [revisionRegFormData, setRevisionRegFormData] = useState<RevisionRegulation>({
    code: '',
    name: '',
    approvalType: '장 승인',
  });
  const [openCombobox, setOpenCombobox] = useState(false);
  const [editingRevisionReg, setEditingRevisionReg] = useState<{ versionId: string; index: number } | null>(null);
  const navigate = useNavigate();

  const handleClearCache = () => {
    localStorage.clear();
    sessionStorage.clear();
    toast.success('캐시가 성공적으로 초기화되었습니다.');
  };

  const handleLogout = () => {
    toast.success('로그아웃 되었습니다.');
    navigate('/');
  };

  const menuItems = [
    { id: 'dashboard' as MenuType, label: '대시보드', icon: LayoutDashboard },
    { id: 'regulations' as MenuType, label: '규정관리', icon: FileText },
    { id: 'revision-version' as MenuType, label: '개정 차수 관리', icon: List },
    { id: 'revision-article' as MenuType, label: '개정 조문 입력', icon: Edit },
    { id: 'validation' as MenuType, label: '오류검증', icon: AlertTriangle },
    { id: 'approval' as MenuType, label: '개정 승인', icon: CheckCircle },
  ];

  const renderContent = () => {
    switch (activeMenu) {
      case 'dashboard':
        return (
          <div>
            <h2 className="text-2xl font-bold text-gray-800 mb-6">대시보드</h2>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardHeader>
                  <CardTitle>전체 정 수</CardTitle>
                  <CardDescription>등록된 규정 현황</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-[#0d4a7a]">248</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>최근 개정</CardTitle>
                  <CardDescription>최근 7일 개정 건수</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-[#FDB71A]">15</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>승인 대기</CardTitle>
                  <CardDescription>승인 대기 중인 개정</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-orange-600">3</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>캐시 관리</CardTitle>
                  <CardDescription>시스템 캐시를 초기화합니다.</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button onClick={handleClearCache} className="w-full bg-[#FDB71A] hover:bg-[#E59A00] text-white">
                    캐시 초기화
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        );
      case 'regulations':
        return (
          <div>
            <h2 className="text-2xl font-bold text-gray-800 mb-6">규정관리</h2>
            <Card>
              <CardHeader>
                <CardTitle>규정 목록</CardTitle>
                <CardDescription>등록된 규정을 관리합니다.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center mb-4">
                  <Button
                    onClick={() => {
                      setFormData({
                        code: '',
                        part: '',
                        chapter: '',
                        name: '',
                        department: '',
                        status: '시행',
                        enactmentDate: '',
                        revisionDate: '',
                        enforcementDate: '',
                        abolitionDate: '',
                      });
                      setEditingRegulation(null);
                      setIsDialogOpen(true);
                    }}
                    className="bg-[#FDB71A] hover:bg-[#E59A00] text-white"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    규정 추가
                  </Button>
                </div>
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="px-4 py-2">코드</th>
                      <th className="px-4 py-2">부분</th>
                      <th className="px-4 py-2">장</th>
                      <th className="px-4 py-2">이름</th>
                      <th className="px-4 py-2">부서</th>
                      <th className="px-4 py-2">상태</th>
                      <th className="px-4 py-2">개정일</th>
                      <th className="px-4 py-2">행사일</th>
                      <th className="px-4 py-2">폐지일</th>
                      <th className="px-4 py-2">작업</th>
                    </tr>
                  </thead>
                  <tbody>
                    {regulations.map((regulation) => (
                      <tr key={regulation.code}>
                        <td className="px-4 py-2">{regulation.code}</td>
                        <td className="px-4 py-2">{regulation.part}</td>
                        <td className="px-4 py-2">{regulation.chapter}</td>
                        <td className="px-4 py-2">{regulation.name}</td>
                        <td className="px-4 py-2">{regulation.department}</td>
                        <td className="px-4 py-2">{regulation.status}</td>
                        <td className="px-4 py-2">{regulation.revisionDate}</td>
                        <td className="px-4 py-2">{regulation.enforcementDate}</td>
                        <td className="px-4 py-2">{regulation.abolitionDate}</td>
                        <td className="px-4 py-2">
                          <Button
                            onClick={() => {
                              setFormData(regulation);
                              setEditingRegulation(regulation);
                              setIsDialogOpen(true);
                            }}
                            className="bg-[#FDB71A] hover:bg-[#E59A00] text-white mr-2"
                          >
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button
                            onClick={() => {
                              setRegulations(regulations.filter((r) => r.code !== regulation.code));
                              toast.success('규정이 공적으로 삭제되었습니다.');
                            }}
                            className="bg-red-500 hover:bg-red-600 text-white"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </CardContent>
            </Card>
          </div>
        );
      case 'revision-version':
        return (
          <div>
            <h2 className="text-2xl font-bold text-gray-800 mb-6">개정 차수 관리</h2>
            <div className="mb-4">
              <Button
                onClick={() => {
                  setVersionFormData({
                    id: '',
                    name: '',
                    status: '작성중',
                    presidentApprovalDate: '',
                    chairmanApprovalDate: '',
                    regulations: [],
                  });
                  setIsVersionDialogOpen(true);
                }}
                className="bg-[#FDB71A] hover:bg-[#E59A00] text-white"
              >
                <Plus className="w-4 h-4 mr-2" />
                개정 수 추가
              </Button>
            </div>
            
            <div className="space-y-4">
              {revisionVersions.map((version) => (
                <Card key={version.id}>
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <div className="flex-1">
                        <CardTitle className="flex items-center gap-2">
                          {version.name}
                          <button
                            onClick={() => {
                              const newExpanded = new Set(expandedVersions);
                              if (newExpanded.has(version.id)) {
                                newExpanded.delete(version.id);
                              } else {
                                newExpanded.add(version.id);
                              }
                              setExpandedVersions(newExpanded);
                            }}
                            className="text-gray-500 hover:text-gray-700"
                          >
                            {expandedVersions.has(version.id) ? (
                              <ChevronUp className="w-5 h-5" />
                            ) : (
                              <ChevronDown className="w-5 h-5" />
                            )}
                          </button>
                        </CardTitle>
                        <CardDescription>
                          상태: {version.status === '작성중' ? '작성중' : '개정완료'} | 
                          {version.status === '개정완료' && ` 총장 승인일: ${version.presidentApprovalDate} | 이사장 승인일: ${version.chairmanApprovalDate}`}
                        </CardDescription>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          onClick={() => {
                            setVersionFormData(version);
                            setIsVersionDialogOpen(true);
                          }}
                          className="bg-[#FDB71A] hover:bg-[#E59A00] text-white"
                          size="sm"
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>
                        <Button
                          onClick={() => {
                            setRevisionVersions(revisionVersions.filter((v) => v.id !== version.id));
                            toast.success('개정 차수가 성공적으로 삭제되었습니다.');
                          }}
                          className="bg-red-500 hover:bg-red-600 text-white"
                          size="sm"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  
                  {expandedVersions.has(version.id) && (
                    <CardContent>
                      <div className="mb-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
                        <h3 className="text-sm font-semibold text-gray-700 mb-3">승인 정보</h3>
                        <div className="grid grid-cols-3 gap-4 items-end">
                          <div>
                            <Label htmlFor={`president-${version.id}`}>총장 승인일</Label>
                            <Input
                              id={`president-${version.id}`}
                              type="date"
                              value={version.presidentApprovalDate}
                              onChange={(e) => {
                                setRevisionVersions(
                                  revisionVersions.map((v) =>
                                    v.id === version.id
                                      ? { ...v, presidentApprovalDate: e.target.value }
                                      : v
                                  )
                                );
                              }}
                              className="w-full"
                            />
                          </div>
                          <div>
                            <Label htmlFor={`chairman-${version.id}`}>이사장 승인일</Label>
                            <Input
                              id={`chairman-${version.id}`}
                              type="date"
                              value={version.chairmanApprovalDate}
                              onChange={(e) => {
                                setRevisionVersions(
                                  revisionVersions.map((v) =>
                                    v.id === version.id
                                      ? { ...v, chairmanApprovalDate: e.target.value }
                                      : v
                                  )
                                );
                              }}
                              className="w-full"
                            />
                          </div>
                          <div>
                            <Button
                              onClick={() => {
                                if (!version.presidentApprovalDate || !version.chairmanApprovalDate) {
                                  toast.error('총장 승인일과 이사장 승인일을 모두 입력해주세요.');
                                  return;
                                }
                                
                                // 각 규정의 승인 구분에 따라 개정일 자동 입력
                                version.regulations.forEach((reg) => {
                                  const approvalDate = reg.approvalType === '이사회 승인' 
                                    ? version.chairmanApprovalDate 
                                    : version.presidentApprovalDate;
                                  
                                  setRegulations((prevRegulations) =>
                                    prevRegulations.map((r) =>
                                      r.code === reg.code
                                        ? { ...r, revisionDate: approvalDate }
                                        : r
                                    )
                                  );
                                });
                                
                                setRevisionVersions(
                                  revisionVersions.map((v) =>
                                    v.id === version.id
                                      ? { ...v, status: '개정완료' }
                                      : v
                                  )
                                );
                                toast.success('개정이 완료되었으며, 각 규정의 개정일이 자동으로 입력되었습니다.');
                              }}
                              className="bg-green-600 hover:bg-green-700 text-white w-full"
                              disabled={version.status === '개정완료'}
                            >
                              {version.status === '개정완료' ? '개정완료됨' : '개정완료'}
                            </Button>
                          </div>
                        </div>
                      </div>

                      <div className="mb-4 flex gap-2">
                        <Button
                          onClick={() => {
                            setCurrentVersionId(version.id);
                            setRevisionRegFormData({
                              code: '',
                              name: '',
                              approvalType: '총장 승인',
                            });
                            setEditingRevisionReg(null);
                            setIsRevisionRegDialogOpen(true);
                          }}
                          className="bg-[#FDB71A] hover:bg-[#E59A00] text-white"
                          size="sm"
                        >
                          <Plus className="w-4 h-4 mr-2" />
                          규정 추가
                        </Button>
                        <Button
                          onClick={() => {
                            setRevisionVersions(
                              revisionVersions.map((v) =>
                                v.id === version.id
                                  ? {
                                      ...v,
                                      regulations: v.regulations.map((r) => ({
                                        ...r,
                                        approvalType: '이사회 승인',
                                      })),
                                    }
                                  : v
                              )
                            );
                            toast.success('모든 규정을 이사회 승인으로 일괄 변경했습니다.');
                          }}
                          className="bg-[#0d4a7a] hover:bg-[#0d4a7a]/90 text-white"
                          size="sm"
                        >
                          이사회 승인 일괄적용
                        </Button>
                        <Button
                          onClick={() => {
                            setRevisionVersions(
                              revisionVersions.map((v) =>
                                v.id === version.id
                                  ? {
                                      ...v,
                                      regulations: v.regulations.map((r) => ({
                                        ...r,
                                        approvalType: '총장 승인',
                                      })),
                                    }
                                  : v
                              )
                            );
                            toast.success('모든 규정을 총장 승인으로 일괄 변경했습니다.');
                          }}
                          className="bg-[#0d4a7a] hover:bg-[#0d4a7a]/90 text-white"
                          size="sm"
                        >
                          총장 승인 일괄적용
                        </Button>
                      </div>
                      
                      {version.regulations.length > 0 ? (
                        <table className="w-full border-collapse">
                          <thead>
                            <tr className="bg-gray-100">
                              <th className="px-4 py-2 text-left">규정 코드</th>
                              <th className="px-4 py-2 text-left">규정명</th>
                              <th className="px-4 py-2 text-left">승인 구분</th>
                              <th className="px-4 py-2 text-left">작업</th>
                            </tr>
                          </thead>
                          <tbody>
                            {version.regulations.map((regulation, idx) => (
                              <tr key={idx} className="border-b">
                                <td className="px-4 py-2">{regulation.code}</td>
                                <td className="px-4 py-2">{regulation.name}</td>
                                <td className="px-4 py-2">
                                  <Select
                                    value={regulation.approvalType}
                                    onValueChange={(value) => {
                                      setRevisionVersions(
                                        revisionVersions.map((v) =>
                                          v.id === version.id
                                            ? {
                                                ...v,
                                                regulations: v.regulations.map((r, i) =>
                                                  i === idx ? { ...r, approvalType: value as ApprovalType } : r
                                                ),
                                              }
                                            : v
                                        )
                                      );
                                    }}
                                  >
                                    <SelectTrigger className="w-40">
                                      <SelectValue>{regulation.approvalType}</SelectValue>
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="이사회 승인">이사회 승인</SelectItem>
                                      <SelectItem value="총장 승인">총장 승인</SelectItem>
                                    </SelectContent>
                                  </Select>
                                </td>
                                <td className="px-4 py-2">
                                  <Button
                                    onClick={() => {
                                      setCurrentVersionId(version.id);
                                      setRevisionRegFormData(regulation);
                                      setEditingRevisionReg({ versionId: version.id, index: idx });
                                      setIsRevisionRegDialogOpen(true);
                                    }}
                                    className="bg-[#FDB71A] hover:bg-[#E59A00] text-white mr-2"
                                    size="sm"
                                  >
                                    <Pencil className="w-4 h-4" />
                                  </Button>
                                  <Button
                                    onClick={() => {
                                      setRevisionVersions(
                                        revisionVersions.map((v) =>
                                          v.id === version.id
                                            ? {
                                                ...v,
                                                regulations: v.regulations.filter((_, i) => i !== idx),
                                              }
                                            : v
                                        )
                                      );
                                      toast.success('규정이 성공적으로 삭제되었습니다.');
                                    }}
                                    className="bg-red-500 hover:bg-red-600 text-white"
                                    size="sm"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </Button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      ) : (
                        <p className="text-gray-500 text-center py-4">등록된 규정이 없습니다.</p>
                      )}
                    </CardContent>
                  )}
                </Card>
              ))}
            </div>
          </div>
        );
      case 'revision-article':
        return (
          <div>
            <h2 className="text-2xl font-bold text-gray-800 mb-6">개정 조문 입력</h2>
            <Card>
              <CardHeader>
                <CardTitle>조문 입력</CardTitle>
                <CardDescription>개정된 조문을 입력합니다.</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center py-8">준비중입니다.</p>
              </CardContent>
            </Card>
          </div>
        );
      case 'validation':
        return (
          <div>
            <h2 className="text-2xl font-bold text-gray-800 mb-6">오류검증</h2>
            <Card>
              <CardHeader>
                <CardTitle>오류 검증</CardTitle>
                <CardDescription>입력된 조문의 오류를 검증합니다.</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">오류 검증 결과가 표시됩니다.</p>
              </CardContent>
            </Card>
          </div>
        );
      case 'approval':
        return (
          <div>
            <h2 className="text-2xl font-bold text-gray-800 mb-6">개정 승인</h2>
            <Card>
              <CardHeader>
                <CardTitle>승인 대기 목록</CardTitle>
                <CardDescription>승인 대기 중인 개정 건을 확인합니다.</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">승인 대기 목록이 표시됩니다.</p>
              </CardContent>
            </Card>
          </div>
        );
    }
  };

  const handleDialogOpen = () => {
    setIsDialogOpen(true);
  };

  const handleDialogClose = () => {
    setIsDialogOpen(false);
  };

  const handleVersionDialogOpen = () => {
    setIsVersionDialogOpen(true);
  };

  const handleVersionDialogClose = () => {
    setIsVersionDialogOpen(false);
  };

  const handleRevisionRegDialogOpen = () => {
    setIsRevisionRegDialogOpen(true);
  };

  const handleRevisionRegDialogClose = () => {
    setIsRevisionRegDialogOpen(false);
  };

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingRegulation) {
      setRegulations(
        regulations.map((regulation) =>
          regulation.code === editingRegulation.code ? { ...regulation, ...formData } : regulation
        )
      );
      toast.success('규정이 성공적으로 수정되었습니다.');
    } else {
      setRegulations([...regulations, formData]);
      toast.success('규정이 성공적으로 추가되었습니다.');
    }
    setIsDialogOpen(false);
  };

  const handleVersionFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setVersionFormData({
      ...versionFormData,
      [name]: value,
    });
  };

  const handleVersionFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (versionFormData.id) {
      setRevisionVersions(
        revisionVersions.map((version) =>
          version.id === versionFormData.id ? { ...version, ...versionFormData } : version
        )
      );
      toast.success('개정 차수가 성공적으로 정되었습니다.');
    } else {
      setRevisionVersions([...revisionVersions, versionFormData]);
      toast.success('개정 차수가 성공적으로 추가되었습니다.');
    }
    setIsVersionDialogOpen(false);
  };

  const handleRevisionRegFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setRevisionRegFormData({
      ...revisionRegFormData,
      [name]: value,
    });
  };

  const handleRevisionRegFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (currentVersionId) {
      setRevisionVersions(
        revisionVersions.map((version) =>
          version.id === currentVersionId
            ? {
                ...version,
                regulations: [
                  ...version.regulations,
                  {
                    code: revisionRegFormData.code,
                    name: revisionRegFormData.name,
                    approvalType: revisionRegFormData.approvalType,
                  },
                ],
              }
            : version
        )
      );
      toast.success('조문이 성공적으로 추가되었습니다.');
    } else if (editingRevisionReg) {
      setRevisionVersions(
        revisionVersions.map((version) =>
          version.id === editingRevisionReg.versionId
            ? {
                ...version,
                regulations: version.regulations.map((regulation, index) =>
                  index === editingRevisionReg.index ? { ...regulation, ...revisionRegFormData } : regulation
                ),
              }
            : version
        )
      );
      toast.success('조문이 성공적으로 수정되었습니다.');
    }
    setIsRevisionRegDialogOpen(false);
  };

  const handleVersionExpand = (id: string) => {
    setExpandedVersions((prev) => {
      if (prev.has(id)) {
        prev.delete(id);
      } else {
        prev.add(id);
      }
      return new Set(prev);
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-[#0d4a7a] text-white flex flex-col">
        <div className="p-6 border-b border-white/10">
          <h1 className="text-xl font-bold">관리자 페이지</h1>
        </div>
        <nav className="flex-1 p-4">
          <ul className="space-y-2">
            {menuItems.map((item) => {
              const Icon = item.icon;
              return (
                <li key={item.id}>
                  <button
                    onClick={() => setActiveMenu(item.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                      activeMenu === item.id
                        ? 'bg-[#FDB71A] text-white'
                        : 'text-white/80 hover:bg-white/10'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span>{item.label}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>
        <div className="p-4 border-t border-white/10">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-white/80 hover:bg-white/10 transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span>로그아웃</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1">
        <main className="p-8">
          {renderContent()}
        </main>
      </div>

      {/* Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingRegulation ? '규정 수정' : '규정 추가'}</DialogTitle>
            <DialogDescription>
              {editingRegulation ? '규정 정보를 수정합니다.' : '새로운 규정을 추가합니다.'}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleFormSubmit}>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="code">코드</Label>
                <Input
                  id="code"
                  name="code"
                  value={formData.code}
                  onChange={handleFormChange}
                  className="w-full"
                />
              </div>
              <div>
                <Label htmlFor="part">부분</Label>
                <Input
                  id="part"
                  name="part"
                  value={formData.part}
                  onChange={handleFormChange}
                  className="w-full"
                />
              </div>
              <div>
                <Label htmlFor="chapter">장</Label>
                <Input
                  id="chapter"
                  name="chapter"
                  value={formData.chapter}
                  onChange={handleFormChange}
                  className="w-full"
                />
              </div>
              <div>
                <Label htmlFor="name">이름</Label>
                <Input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleFormChange}
                  className="w-full"
                />
              </div>
              <div>
                <Label htmlFor="department">부서</Label>
                <Input
                  id="department"
                  name="department"
                  value={formData.department}
                  onChange={handleFormChange}
                  className="w-full"
                />
              </div>
              <div>
                <Label htmlFor="status">상태</Label>
                <Select
                  value={formData.status}
                  onValueChange={(value) => setFormData({ ...formData, status: value as RegulationStatus })}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue>{formData.status}</SelectValue>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="시행예정">시행예정</SelectItem>
                    <SelectItem value="시행">시행</SelectItem>
                    <SelectItem value="폐지">폐지</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="enactmentDate">개정일</Label>
                <Input
                  id="enactmentDate"
                  name="enactmentDate"
                  type="date"
                  value={formData.enactmentDate}
                  onChange={handleFormChange}
                  className="w-full"
                />
              </div>
              <div>
                <Label htmlFor="revisionDate">개정일</Label>
                <Input
                  id="revisionDate"
                  name="revisionDate"
                  type="date"
                  value={formData.revisionDate}
                  onChange={handleFormChange}
                  className="w-full"
                />
              </div>
              <div>
                <Label htmlFor="enforcementDate">행사일</Label>
                <Input
                  id="enforcementDate"
                  name="enforcementDate"
                  type="date"
                  value={formData.enforcementDate}
                  onChange={handleFormChange}
                  className="w-full"
                />
              </div>
              <div>
                <Label htmlFor="abolitionDate">폐지일</Label>
                <Input
                  id="abolitionDate"
                  name="abolitionDate"
                  type="date"
                  value={formData.abolitionDate}
                  onChange={handleFormChange}
                  className="w-full"
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" onClick={handleDialogClose} className="bg-gray-500 hover:bg-gray-600 text-white">
                취소
              </Button>
              <Button type="submit" className="bg-[#FDB71A] hover:bg-[#E59A00] text-white">
                저장
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Version Dialog */}
      <Dialog open={isVersionDialogOpen} onOpenChange={setIsVersionDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{versionFormData.id ? '개정 차수 수정' : '개정 차수 추가'}</DialogTitle>
            <DialogDescription>
              {versionFormData.id ? '개정 차수 정보를 수정합니다.' : '새로운 개정 차수를 추가합니다.'}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleVersionFormSubmit}>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="id">ID</Label>
                <Input
                  id="id"
                  name="id"
                  value={versionFormData.id}
                  onChange={handleVersionFormChange}
                  className="w-full"
                />
              </div>
              <div>
                <Label htmlFor="name">이름</Label>
                <Input
                  id="name"
                  name="name"
                  value={versionFormData.name}
                  onChange={handleVersionFormChange}
                  className="w-full"
                />
              </div>
              <div>
                <Label htmlFor="status">상태</Label>
                <Select
                  value={versionFormData.status}
                  onValueChange={(value) => setVersionFormData({ ...versionFormData, status: value as RevisionStatus })}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue>{versionFormData.status}</SelectValue>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="작성중">작성중</SelectItem>
                    <SelectItem value="개정완료">개정완료</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="presidentApprovalDate">총장 승인일</Label>
                <Input
                  id="presidentApprovalDate"
                  name="presidentApprovalDate"
                  type="date"
                  value={versionFormData.presidentApprovalDate}
                  onChange={handleVersionFormChange}
                  className="w-full"
                />
              </div>
              <div>
                <Label htmlFor="chairmanApprovalDate">이사회 승인일</Label>
                <Input
                  id="chairmanApprovalDate"
                  name="chairmanApprovalDate"
                  type="date"
                  value={versionFormData.chairmanApprovalDate}
                  onChange={handleVersionFormChange}
                  className="w-full"
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" onClick={handleVersionDialogClose} className="bg-gray-500 hover:bg-gray-600 text-white">
                취소
              </Button>
              <Button type="submit" className="bg-[#FDB71A] hover:bg-[#E59A00] text-white">
                저장
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Revision Regulation Dialog */}
      <Dialog open={isRevisionRegDialogOpen} onOpenChange={setIsRevisionRegDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>조문 추가</DialogTitle>
            <DialogDescription>
              개정 차수에 새로운 규정을 추가합니다.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleRevisionRegFormSubmit}>
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2">
                <Label>규정명</Label>
                <Popover open={openCombobox} onOpenChange={setOpenCombobox}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      role="combobox"
                      aria-expanded={openCombobox}
                      className="w-full justify-between"
                    >
                      {revisionRegFormData.name || "규정을 선택하세요..."}
                      <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-full p-0">
                    <Command>
                      <CommandInput placeholder="규정 검색..." />
                      <CommandList>
                        <CommandEmpty>검색 결과가 없습니다.</CommandEmpty>
                        <CommandGroup>
                          {regulations.map((regulation) => (
                            <CommandItem
                              key={regulation.code}
                              value={regulation.name}
                              onSelect={(currentValue) => {
                                setRevisionRegFormData({
                                  ...revisionRegFormData,
                                  code: regulation.code,
                                  name: regulation.name,
                                });
                                setOpenCombobox(false);
                              }}
                            >
                              <Check
                                className={cn(
                                  'mr-2 h-4 w-4',
                                  revisionRegFormData.name === regulation.name ? 'opacity-100' : 'opacity-0'
                                )}
                              />
                              {regulation.name} ({regulation.code})
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>
              </div>
              <div>
                <Label htmlFor="approvalType">승인 유형</Label>
                <Select
                  value={revisionRegFormData.approvalType}
                  onValueChange={(value) => setRevisionRegFormData({ ...revisionRegFormData, approvalType: value as ApprovalType })}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue>{revisionRegFormData.approvalType}</SelectValue>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="이사회 승인">이사회 승인</SelectItem>
                    <SelectItem value="총장 승인">총장 승인</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" onClick={handleRevisionRegDialogClose} className="bg-gray-500 hover:bg-gray-600 text-white">
                취소
              </Button>
              <Button type="submit" className="bg-[#FDB71A] hover:bg-[#E59A00] text-white">
                저장
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}