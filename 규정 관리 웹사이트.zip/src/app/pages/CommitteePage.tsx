import { CategoryPage } from './CategoryPage';

const mockRegulations = [
  { id: 9, title: '부산외국어대학교 대학평의원회 규정', date: '2024.02.15', category: '위원회', status: 'active' as const },
  { id: 10, title: '부산외국어대학교 교무위원회 규정', date: '2024.01.10', category: '위원회', status: 'active' as const },
  { id: 11, title: '부산외국어대학교 인사위원회 규정', date: '2023.12.20', category: '위원회', status: 'active' as const },
  { id: 12, title: '부산외국어대학교 예산위원회 규정', date: '2024.03.05', category: '위원회', status: 'active' as const },
];

export function CommitteePage() {
  return <CategoryPage category="위원회" regulations={mockRegulations} />;
}
