import { useState } from 'react';
import { useParams, useSearchParams, useNavigate } from 'react-router';
import { ChevronDown, ChevronRight, Calendar, Download, ArrowLeft } from 'lucide-react';
import { HeaderWithSearch } from '../components/HeaderWithSearch';
import { Button } from '../components/ui/button';
import { AdminButton } from '../components/AdminButton';

// 모의 규정 데이터
const mockRegulation = {
  id: 1,
  regulationNumber: 1,
  title: '부산외국어대학교 학칙',
  enactmentDate: '2022.09.01',
  latestRevision: '2024.03.01',
  category: '학칙',
  chapters: [
    {
      id: 'ch1',
      title: '제1장 총칙',
      sections: [],
      articles: [
        { 
          id: 'art1', 
          number: '제1조', 
          title: '목적', 
          content: '이 학칙은 부산외국어대학교(이하 "본 대학교"라 한다)의 교육이념을 구현하고, 학생의 학습권을 보장하며, 대학의 건전한 발전을 도모하기 위하여 필요한 사항을 규정함을 목적으로 한다.'
        },
        { 
          id: 'art2', 
          number: '제2조', 
          title: '설립이념', 
          content: '본 대학교는 국가와 인류사회 발전에 기여할 수 있는 유능한 인재를 양성함을 목적으로 한다.'
        },
        { 
          id: 'art3', 
          number: '제3조', 
          title: '학생의 권리와 의무', 
          content: '① 학생은 학칙이 정하는 바에 따라 수학할 권리를 가지며, 학칙 및 제 규정을 준수할 의무를 진다.\n② 학생은 교육과정에 참여하고 학업성적을 평가받을 권리를 가진다.\n③ 학생은 본 대학교의 명예와 품위를 손상시키는 행위를 하여서는 아니 된다.'
        },
      ]
    },
    {
      id: 'ch2',
      title: '제2장 학사조직',
      sections: [
        {
          id: 'sec1',
          title: '제1절 학부 및 학과',
          articles: [
            { 
              id: 'art4', 
              number: '제4조', 
              title: '학부 및 학과의 설치', 
              content: '본 대학교에는 다음의 학부 및 학과를 둔다.\n1. 영어학부\n2. 중국어학부\n3. 일본어학부\n4. 유럽언어문화학부\n5. 국제통상학부'
            },
            { 
              id: 'art5', 
              number: '제5조', 
              title: '학부 및 학과의 운영', 
              content: '① 각 학부 및 학과에는 학부장 또는 학과장을 둔다.\n② 학부장 및 학과장은 총장이 임명한다.\n③ 학부장 및 학과장의 임기는 2년으로 하되, 연임할 수 있다.'
            },
          ]
        },
        {
          id: 'sec2',
          title: '제2절 ',
          articles: [
            { 
              id: 'art6', 
              number: '제6조', 
              title: '대학원의 설치', 
              content: '본 대학교에 일반대학원, 특수대학원 및 전문대학원을 둘 수 있다.'
            },
          ]
        },
      ],
      articles: []
    },
    {
      id: 'ch3',
      title: '제3장 학사운영',
      sections: [],
      articles: [
        { 
          id: 'art7', 
          number: '제7조', 
          title: '학기 및 수업일수', 
          content: '① 학년은 매년 3월 1일부터 다음 해 2월 말일까지로 한다.\n② 학기는 2학기로 나누며, 제1학기는 3월 1일부터 8월 31일까지, 제2학기는 9월 1일부터 다음 해 2월 말일까지로 한다.\n③ 수업일수는 매 학기 15주 이상으로 한다.'
        },
        { 
          id: 'art8', 
          number: '제8조', 
          title: '휴업일', 
          content: '① 휴업일은 다음과 같다.\n1. 국정공휴일\n2. 개교기념일\n3. 하계 및 동계방학\n② 총장은 필요하다고 인정할 때에는 휴업일을 변경하거나 임시휴업을 할 수 있다.'
        },
      ]
    },
  ]
};

interface TreeNodeProps {
  title: string;
  children?: React.ReactNode;
  onClick?: () => void;
  isActive?: boolean;
}

// 조문 내용을 파싱하여 들여쓰기를 적용하는 컴포넌트
function ArticleContent({ number, title, content }: { number: string; title: string; content: string }) {
  const lines = content.split('\n');
  
  const getIndentClass = (line: string, index: number) => {
    const trimmedLine = line.trim();
    
    // 항 번호 체크 (①, ②, ③ 등) - 첫 번째 항(①)만 들여쓰기 없음
    if (/^[①②③④⑤⑥⑦⑧⑨⑩]/.test(trimmedLine)) {
      if (trimmedLine.startsWith('①')) {
        return ''; // 제1항은 들여쓰기 없음
      }
      return 'pl-[10pt]'; // 제2항부터 10pt
    }
    
    // 호 번호 체크 (1., 2., 3. 등)
    if (/^\d+\./.test(trimmedLine)) {
      return 'pl-[20pt]'; // 20pt
    }
    
    // 목 번호 체크 (가., 나., 다. 등)
    if (/^[가-힣]\./.test(trimmedLine)) {
      return 'pl-[30pt]'; // 30pt
    }
    
    return '';
  };

  return (
    <div className="text-foreground leading-relaxed">
      <div>
        <span className="font-bold">{number} ({title})</span> {lines[0]}
      </div>
      {lines.slice(1).map((line, index) => (
        line.trim() && (
          <div key={index} className={getIndentClass(line, index + 1)}>
            {line.trim()}
          </div>
        )
      ))}
    </div>
  );
}

function TreeNode({ title, children, onClick, isActive }: TreeNodeProps) {
  const [isOpen, setIsOpen] = useState(true);
  const hasChildren = !!children;

  return (
    <div>
      <div
        className={`flex items-center gap-2 py-2 px-3 rounded cursor-pointer transition-colors ${
          isActive ? 'bg-primary text-primary-foreground' : 'hover:bg-accent'
        }`}
        onClick={() => {
          if (hasChildren) {
            setIsOpen(!isOpen);
          }
          if (onClick) {
            onClick();
          }
        }}
      >
        {hasChildren && (
          isOpen ? <ChevronDown className="w-4 h-4 flex-shrink-0" /> : <ChevronRight className="w-4 h-4 flex-shrink-0" />
        )}
        {!hasChildren && <div className="w-4" />}
        <span className="text-sm break-keep">{title}</span>
      </div>
      {hasChildren && isOpen && (
        <div className="ml-4 border-l border-border pl-2">
          {children}
        </div>
      )}
    </div>
  );
}

export function RegulationDetail() {
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const targetArticle = searchParams.get('article');
  const [activeArticle, setActiveArticle] = useState<string>(targetArticle || 'art1');
  const navigate = useNavigate();

  const scrollToArticle = (articleId: string) => {
    setActiveArticle(articleId);
    const element = document.getElementById(articleId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const findArticleById = (articleId: string) => {
    for (const chapter of mockRegulation.chapters) {
      const article = chapter.articles.find(a => a.id === articleId);
      if (article) return article;
      
      for (const section of chapter.sections) {
        const sectionArticle = section.articles.find(a => a.id === articleId);
        if (sectionArticle) return sectionArticle;
      }
    }
    return null;
  };

  const currentArticle = findArticleById(activeArticle);

  return (
    <div className="min-h-screen bg-background">
      <HeaderWithSearch />
      
      <div className="max-w-7xl mx-auto px-8">
        <div className="flex">
          {/* 좌측 네비게이션 */}
          <aside className="w-80 border-r h-[calc(100vh-73px)] sticky top-[73px] overflow-y-auto bg-white -ml-8 pl-8">
            <div className="p-6">
              <button
                onClick={() => navigate(-1)}
                className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors mb-4 pb-4 border-b w-full py-3"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>검색 결과로 돌아가기</span>
              </button>
              
              <h3 className="font-bold mb-4 pb-3 border-b">{mockRegulation.title}</h3>
              <div className="space-y-1">
                {mockRegulation.chapters.map((chapter) => (
                  <TreeNode key={chapter.id} title={chapter.title}>
                    {chapter.sections.length > 0 ? (
                      chapter.sections.map((section) => (
                        <TreeNode key={section.id} title={section.title}>
                          {section.articles.map((article) => (
                            <TreeNode
                              key={article.id}
                              title={`${article.number} ${article.title}`}
                              onClick={() => scrollToArticle(article.id)}
                              isActive={activeArticle === article.id}
                            />
                          ))}
                        </TreeNode>
                      ))
                    ) : (
                      chapter.articles.map((article) => (
                        <TreeNode
                          key={article.id}
                          title={`${article.number} ${article.title}`}
                          onClick={() => scrollToArticle(article.id)}
                          isActive={activeArticle === article.id}
                        />
                      ))
                    )}
                  </TreeNode>
                ))}
              </div>
            </div>
          </aside>

          {/* 본문 */}
          <main className="flex-1 py-8 pl-8 bg-white">
            <div className="mb-8 pb-6 border-b-2 border-border">
              <div className="text-center mb-6">
                <span className="inline-block px-3 py-1 bg-[#0d4a7a]/10 text-[#0d4a7a] rounded text-sm font-medium mb-3">
                  제{mockRegulation.regulationNumber}편 {mockRegulation.category}
                </span>
                <h1 className="text-3xl mt-2">{mockRegulation.title}</h1>
              </div>
              <div className="flex items-start justify-between">
                <div className="flex flex-col gap-1 text-sm text-muted-foreground">
                  <div>
                    <span>제정 : {mockRegulation.enactmentDate}</span>
                  </div>
                  <div>
                    <span>개정 : {mockRegulation.latestRevision}</span>
                  </div>
                </div>
                <Button variant="outline" className="gap-2 border-border">
                  <Download className="w-4 h-4" />
                  다운로드
                </Button>
              </div>
            </div>

            <div className="space-y-8">
              {mockRegulation.chapters.map((chapter) => (
                <div key={chapter.id} className="space-y-6">
                  <h2 className="text-xl font-bold pb-3 border-b border-primary text-center">{chapter.title}</h2>
                  
                  {chapter.articles.map((article) => (
                    <div 
                      key={article.id} 
                      id={article.id}
                      className={`pb-6 scroll-mt-24 ${
                        activeArticle === article.id ? 'border-l-4 border-primary pl-6 bg-accent/20' : 'pl-2'
                      }`}
                    >
                      <ArticleContent number={article.number} title={article.title} content={article.content} />
                    </div>
                  ))}

                  {chapter.sections.map((section) => (
                    <div key={section.id} className="space-y-6">
                      <h3 className="text-lg font-bold pl-4 border-l-4 border-primary/60 mt-8">
                        {section.title}
                      </h3>
                      {section.articles.map((article) => (
                        <div 
                          key={article.id} 
                          id={article.id}
                          className={`pb-6 scroll-mt-24 ${
                            activeArticle === article.id ? 'border-l-4 border-primary pl-6 bg-accent/20' : 'pl-2'
                          }`}
                        >
                          <ArticleContent number={article.number} title={article.title} content={article.content} />
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </main>
        </div>
      </div>

      <AdminButton />
    </div>
  );
}