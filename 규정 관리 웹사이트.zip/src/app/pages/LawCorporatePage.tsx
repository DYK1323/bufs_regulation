import { CategoryPage } from './CategoryPage';

const mockRegulations = [
  { id: 1, title: '학교법인 부산외국어대학교 정관', date: '2024.03.01', category: '법인', status: 'active' as const },
  { id: 2, title: '학교법인 부산외국어대학교 이사회 운영규정', date: '2024.01.15', category: '법인', status: 'active' as const },
  { id: 3, title: '학교법인 부산외국어대학교 임원 보수규정', date: '2023.12.01', category: '법인', status: 'revised' as const },
  { id: 4, title: '학교법인 부산외국어대학교 회계규정', date: '2024.02.10', category: '법인', status: 'active' as const },
];

export function LawCorporatePage() {
  return <CategoryPage category="법인" regulations={mockRegulations} />;
}
